package abbot.editor.editors;

import javax.swing.*;

import junit.extensions.abbot.*;
import abbot.script.*;
import abbot.tester.JTextComponentTester;
import abbot.finder.matchers.*;

/** Verify CallEditor operation. */

public class CallEditorTest
    extends ResolverFixture implements XMLConstants {

    private Call call;
    private CallEditor editor;
    private JTextComponentTester tester;

    protected void setUp() {
        call = new Call(getResolver(), null,
                        "java.lang.Object", "hashCode", null);
        editor = new CallEditor(call);
        tester = new JTextComponentTester();
    }

    public void testMethodList() throws Throwable {
        showFrame(editor);
        JComboBox cb = getMethodComboBox(editor);
        assertEquals("Wrong method selected",
                     cb.getSelectedItem(), "hashCode");
        String[] expected = {
            "equals",
            "getClass",
            "hashCode",
            "notify",
            "notifyAll",
            "toString",
            "wait",
        };
        assertEquals("Wrong number of methods",
                     expected.length, cb.getItemCount());
        for (int i=0;i < cb.getItemCount();i++) {
            assertEquals("Wrong method in combo list",
                         expected[i], cb.getItemAt(i));
        }
    }

    public void testMethodListUpdateOnClassChange() throws Exception {
        showFrame(editor);
        JTextField tf = getTargetClassBox(editor);
        JComboBox cb = getMethodComboBox(editor);
        int count = cb.getItemCount();
        String TEXT = "abbot.tester.ComponentTester";
        tester.actionEnterText(tf, TEXT);
        assertEquals("Text entered improperly", TEXT, tf.getText());
        assertTrue("Method list was not updated", count != cb.getItemCount());
    }

    protected JTextField getTargetClassBox(CallEditor editor)
        throws Exception
    {
        return (JTextField)getFinder().
            find(editor, new NameMatcher(TAG_CLASS));
    }

    protected JComboBox getMethodComboBox(CallEditor editor) throws Exception {
        return (JComboBox)getFinder().
            find(editor, new NameMatcher(TAG_METHOD));
    }

    /** Construct a test case with the given name. */
    public CallEditorTest(String name) {
        super(name);
    }

    /** Run the default test suite. */
    public static void main(String[] args) {
        RepeatHelper.runTests(args, CallEditorTest.class);
    }
}
