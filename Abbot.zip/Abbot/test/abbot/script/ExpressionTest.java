package abbot.script;

import junit.extensions.abbot.*;

public class ExpressionTest extends ResolverFixture {

    public void testFromXML() throws Throwable {
        String EXPR = "System.out.println(\"hello\");";
        String XML = "<expression><![CDATA[" + EXPR + "]]></expression>";

        Expression e = (Expression)Step.createStep(getResolver(), XML);
        assertEquals("Wrong expression parsed", EXPR, e.getExpression());

        assertEquals("Wrong encoding", XML, Step.toXMLString(e));
    }

    public void testSimpleExpression() throws Throwable {
        Expression e = new Expression(getResolver(), getName());
        assertEquals("Default expression should be empty",
                     "", e.getExpression());

        e.setExpression("i=10;");
        e.runStep();
        Interpreter sh = (Interpreter)
            getResolver().getProperty(Script.INTERPRETER);
        assertEquals("Wrong value for expression",
                     new Integer(10), sh.get("i"));
    }
    
    public void testVariableExpansion() throws Throwable {
        Expression e = new Expression(getResolver(), getName());
        assertEquals("Default expression should be empty",
                     "", e.getExpression());

        final String NAME = "bloody hell";
        getResolver().setProperty("name", NAME);
        e.setExpression("name=\"${name}\";");
        e.runStep();
        Interpreter sh = (Interpreter)
            getResolver().getProperty(Script.INTERPRETER);
        assertEquals("Wrong value for expression",
                     NAME, sh.get("name"));
    }

    public ExpressionTest(String name) { super(name); }

    public static void main(String[] args) {
        TestHelper.runTests(args, ExpressionTest.class);
    }
}

