package abbot.tester;

import java.awt.Component;
import java.awt.Container;
import java.util.ArrayList;

import javax.swing.*;

import abbot.Log;
import abbot.i18n.Strings;
import abbot.util.ExtendedComparator;
import abbot.util.AWT;
import abbot.finder.*;
import abbot.finder.matchers.*;

/**
 * JComboBoxTester for testing JComboBox instances.
 * 
 * <p>In the case where you need to create a tester for JComboBox subclasses that
 * use novel components in the popup, for example jtree, you can quickly subclass
 * this tester to deal with those cases without the need to create a seperate
 * Recorder. Simply override the selectItemInPopup, getTargetClass, getValueAsStringFromRenderer
 * and findPopupComponent(Container) to return relavent values for your subclass
 * of JComboBox.</p>
 */

public class JComboBoxTester extends JComponentTester {

    private class PopupNotFoundException extends ActionFailedException {
        public PopupNotFoundException(String m) { super(m); }
    }
    private JListTester listTester = new JListTester();

    /** Return an array of strings that represent the combo box list. 
     * Note that the current selection might not be included, since it's
     * possible to have a custom (edited) entry there that is not included in
     * the default contents.
     */
    public String[] getContents(JComboBox cb) {
        ArrayList list = new ArrayList();
        for (int i=0;i < cb.getItemCount();i++) {
            list.add(cb.getItemAt(i).toString());
        }
        return (String[])list.toArray(new String[list.size()]);
    }

    public void actionSelectIndex(Component comp, final int index) {
        final JComboBox cb = (JComboBox)comp;

        // activate it, if not already showing 
        if (!cb.getUI().isPopupVisible(cb)) {
            // NOTE: if the index is out of range, the selected item will be
            // one end or the other of the list.
            if (cb.isEditable()) {
                // Location of popup button activator is LAF-dependent
                invokeAndWait(new Runnable() {
                    public void run() { 
                        cb.getUI().setPopupVisible(cb, true);
                    }
                });
            }
            else {
                actionClick(cb);
            }
        }
        try {
            // Not all LAFs use a JList for the popup
            Component popup = findPopupComponent(cb);
            selectIndexInPopup(popup, index);
        }
        catch(PopupNotFoundException e) {
            invokeAndWait(new Runnable() {
                public void run() {
                    cb.setSelectedIndex(index);
                    if (cb.getUI().isPopupVisible(cb))
                        cb.getUI().setPopupVisible(cb, false);
                }
            });
        }
    }
    
    /** Provide an override point to select the correct index in whatever index
        the recording has specified
    */
    protected void selectIndexInPopup(Component popup, int index) {
        listTester.actionSelectIndex(popup, index);
    }
    

    /** Find the component in the popup raised by this combo box, if
        the LAF actually uses one. 
    */
    public Component findPopupComponent(JComboBox cb) {
        Component popup = AWT.findActivePopupMenu();
        if (popup == null) {
            long now = System.currentTimeMillis();
            while ((popup = AWT.findActivePopupMenu()) == null) {
                if (System.currentTimeMillis() - now > popupDelay)
                    throw new PopupNotFoundException(Strings.get("tester.JComboBox.popup_not_found"));
                sleep();
            }
        }
        
        Component comp = findPopupComponent((Container)popup);
        if (comp == null)
            throw new PopupNotFoundException(Strings.get("tester.JComboBox.popup_not_found"));
        return comp;
    }

   
    /** Find the correct popup component in the container */
    protected Component findPopupComponent(Container parent) {
        try {
            ComponentFinder finder = BasicFinder.getDefault();
            return finder.find(parent, new ClassMatcher(JList.class));
        }
        catch(ComponentSearchException e) {
            return null;
        }
    }

    /** If the value looks meaningful, return it, otherwise return null. */
    public String getValueAsString(JComboBox combo,
                                   Component popupComponent,
                                   Object item, int index) {
        String value = item.toString();
        // If the value is the default Object.toString method (which
        // returns <class>@<pointer value>), try to find something better.
        if (value.startsWith(item.getClass().getName() + "@")) {
            return getValueAsStringFromRenderer(combo, popupComponent, item, index);
        }
        return value;
    }
    
    
    /** Allow the recorder to write out the correct class name.  */
    public Class getTargetClass() {
        return JComboBox.class;
    }


    /** Convert the value to a string using a local render */
    protected String getValueAsStringFromRenderer(JComboBox combo,
                                                Component popupComponent,
                                                Object item, int index) {
        Component c = combo.getRenderer().
            getListCellRendererComponent((JList)popupComponent, item, index, true, true);
        if (c instanceof javax.swing.JLabel)
            return ((javax.swing.JLabel)c).getText();
        return null;
    }
    
    
    

    public void actionSelectItem(Component comp, String item) {
        JComboBox cb = (JComboBox)comp;
        Object obj = cb.getSelectedItem();
        if ((obj == null && item == null)
            || (obj != null
                && ExtendedComparator.stringsMatch(item, obj.toString())))
            return;

        for (int i=0;i < cb.getItemCount();i++) {
            obj = cb.getItemAt(i);
            Log.debug("Comparing against '" + obj + "'");
            if ((obj == null && item == null)
                || (obj != null
                    && ExtendedComparator.stringsMatch(item, obj.toString()))){
                actionSelectIndex(comp, i);
                return;
            }
        }
        // While actions are supposed to represent real user actions, it's
        // possible that the current environment does not match sufficiently,
        // so we need to throw an appropriate exception that can be used to
        // diagnose the problem.
        String mid = "[";
        StringBuffer contents = new StringBuffer();
        for (int i=0;i < cb.getItemCount();i++) {
            contents.append(mid);
            contents.append(cb.getItemAt(i).toString());
            mid = ", ";
        }
        contents.append("]");
        throw new ActionFailedException(Strings.get("tester.JComboBox.item_not_found",
                                                    new Object[] {
                                                        item,
                                                        contents.toString()
                                                    }));
    }
}
