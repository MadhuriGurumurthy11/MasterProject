package abbot.tester;

import java.awt.*;

import javax.swing.*;

import abbot.Log;
import abbot.i18n.Strings;
import abbot.script.ArgumentParser;
import abbot.util.Condition;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

/** Provide actions and assertions for a {@link JList} component.
    The {@link JList} substructure is a "row", and {@link JListLocation}
    provides different identifiers for a row.
    <ul>
    <li>Select an item by index
    <li>Select an item by value (its string representation)
    </ul>
    Note that {@link JList} uses "index" and "value" in its API.  For
    convenience, the <code>JListTester</code> API also provides "row" and
    "item" as synonyms for "index".

    @see JListLocation
 */
// TODO multi-select

public class JListTester extends JComponentTester {

    /** Convert the value in the list at the given index into a reasonable
        string representation, or null if one can not be obtained.
     */
    public static String valueToString(final JList list, final int index) {

        // Ensure this work is done on the EDT, TODO move this
        // code up to Robot if we are sure we need to reuse it
        //

        Callable renderedToString = new Callable() {
            public Object call() {
                Object value = list.getModel().getElementAt(index);
                Component cr =
                    list.getCellRenderer().getListCellRendererComponent(list,
                                                                        value,
                                                                        index,
                                                                        false,
                                                                        false);
                String string = convertRendererToString(cr);
                return string;
            }
        };


        try {
            if (EventQueue.isDispatchThread()) {
                return (String)renderedToString.call();
            }
            else {
                
                // TODO make sure we use the correct event queue, this method cannot be static
                //
                
                FutureTask ft = new FutureTask(renderedToString);
                EventQueue.invokeLater(ft);
                return (String)ft.get();
            }
        } catch (Exception e) {
            throw new RuntimeException("Failure to query string value", e);
        }
    }

    /** JList doesn't provide direct access to its contents, so make up for
     * that oversight.
     */
    public Object getElementAt(JList list, int index) {
        return list.getModel().getElementAt(index);
    }

    /** Return the size of the given list. */
    public int getSize(JList list) {
        return list.getModel().getSize();
    }

    /** Return an array of strings that represents the list's contents. */
    public String[] getContents(JList list) {
        ListModel model = list.getModel();
        String[] values = new String[model.getSize()];
        for (int i=0;i < values.length;i++) {
            values[i] = model.getElementAt(i).toString();
        }
        return values;
    }

    /** Select the given index.
        Equivalent to actionSelectRow(c, new JListLocation(index), delay).
    */
    public void actionSelectIndex(Component c, int index, long delay) {
        actionSelectRow(c, new JListLocation(index), delay);
    }

    /** Select the given index.
        Equivalent to actionSelectRow(c, new JListLocation(index)).
    */
    public void actionSelectIndex(Component c, int index) {
        actionSelectRow(c, new JListLocation(index));
    }

    /** Select the first item in the list matching the given String
        representation of the item.<p>
        Equivalent to actionSelectRow(c, new JListLocation(item), delay).
    */
    public void actionSelectItem(Component c, String item,long delay) {
        actionSelectRow(c, new JListLocation(item), delay);
    }

    /** Select the first item in the list matching the given String
        representation of the item.<p>
        Equivalent to actionSelectRow(c, new JListLocation(item)).
    */
    public void actionSelectItem(Component c, String item) {
        actionSelectRow(c, new JListLocation(item));
    }

    /** Select the first value in the list matching the given String
        representation of the value.<p>
        Equivalent to actionSelectRow(c, new JListLocation(value)).
    */
    public void actionSelectValue(Component c, String value) {
        actionSelectRow(c, new JListLocation(value));
    }

    /** Select the given row.  Does nothing if the index is already
     * selected.
     */
    public void actionSelectRow(Component c, final JListLocation location) {
        actionSelectRow(c,location, componentDelay);
    }
    
    /** Select the given row.  Does nothing if the index is already
     * selected.
     */
    public void actionSelectRow(Component c, final JListLocation location, long delay) {
        final JList list = (JList)c;

        // Wait for the selected location to become avaliable
        //

        wait(new Condition() {
                    public boolean test() {
                        int index = location.getIndex(list);
                        return index >= 0 && index < list.getModel().getSize();
                    }

                    public String toString() {
                        return Strings.get("tester.Component.show_wait",
                                           new Object[] { location.toString() });
                    }
                }, delay);

        // Select the location
        // 

        int index = location.getIndex(list);
        if (index < 0 || index >= list.getModel().getSize()) {
            String msg = Strings.get("tester.JList.invalid_index",
                                     new Object[] { new Integer(index) });
            throw new ActionFailedException(msg);
        }
        if (list.getSelectedIndex() != index) {
            Log.debug("Click on index=" + index);
            super.actionClick(c, location);
        }
    }

    /** Parse the String representation of a JListLocation into the actual
        JListLocation object.
    */
    public ComponentLocation parseLocation(String encoded) {
        return new JListLocation().parse(encoded);
    }

    /** Return the value, row, or coordinate location. */
    public ComponentLocation getLocation(Component c, Point p) {
        JList list = (JList)c;
        int index = list.locationToIndex(p);
        String value = valueToString(list, index);
        if (value != null) {
            return new JListLocation(value);
        }
        else if (index != -1) {
            return new JListLocation(index);
        }
        return new JListLocation(p);
    }
}
