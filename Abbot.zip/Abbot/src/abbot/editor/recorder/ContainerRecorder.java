package abbot.editor.recorder;

import abbot.script.Resolver;

/**
 * Record basic semantic events you might find on an Container. <p>
 */
public class ContainerRecorder extends ComponentRecorder {

    public ContainerRecorder(Resolver resolver) {
        super(resolver);
    }
}

