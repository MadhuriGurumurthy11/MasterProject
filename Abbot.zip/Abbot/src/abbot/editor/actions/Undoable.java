package abbot.editor.actions;

public interface Undoable {
    public void undo();
}
